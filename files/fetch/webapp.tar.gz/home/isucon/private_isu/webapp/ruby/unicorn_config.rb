worker_processes 1
preload_app true
listen "0.0.0.0:8080"
